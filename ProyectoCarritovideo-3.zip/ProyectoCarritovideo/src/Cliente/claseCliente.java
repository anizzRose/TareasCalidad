
package Cliente;


public class claseCliente {
  private int id_cliente;
  private String nombre;
  private String apellidos;
  private String correo;
  private int edad;
  private String contrasena;
  private String usuario;
  
  public claseCliente(){
      
  }
  
  public claseCliente(int id_cliente,String nombre,String apellidos,String correo,int edad,String usuario,String contrasena){
      this.id_cliente=id_cliente;
      this.nombre=nombre;
      this.apellidos=apellidos;
      this.usuario=usuario;
      this.edad=edad;
      this.correo=correo;
      this.contrasena=contrasena;
  }

    
    public int getId_cliente() {
        return id_cliente;
    }

    
    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

   
    public String getNombre() {
        return nombre;
    }

   
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the apellidos
     */
    public String getApellidos() {
        return apellidos;
    }

    /**
     * @param apellidos the apellidos to set
     */
    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    /**
     * @return the correo
     */
    public String getCorreo() {
        return correo;
    }

    /**
     * @param correo the correo to set
     */
    public void setCorreo(String correo) {
        this.correo = correo;
    }

    /**
     * @return the edad
     */
    public int getEdad() {
        return edad;
    }

    
    public void setEdad(int edad) {
        this.edad = edad;
    }

   
    public String getContrasena() {
        return contrasena;
    }

    
    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    
    public String getUsuario() {
        return usuario;
    }

    
    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }
 
    
}
