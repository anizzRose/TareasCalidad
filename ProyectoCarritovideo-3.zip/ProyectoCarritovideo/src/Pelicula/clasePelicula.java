
package Pelicula;


public class clasePelicula {
    
    private int Id_pelicula;
    private String nombrepelicula;
    private String director;
    private String protagonista;
    private String genero;
    private double precioventa;
    private double preciorenta;
    
    public clasePelicula(){
    precioventa=0;
    preciorenta=0;
    }
    
    public clasePelicula(int Id_pelicula,String nombrepelicula,String director,String protagonista,String genero,double precioventa,double preciorenta){
        
        this.Id_pelicula=Id_pelicula;
        this.nombrepelicula=nombrepelicula;
        this.director=director;
        this.protagonista=protagonista;
        this.genero=genero;
        this.precioventa=precioventa;
        this.preciorenta=preciorenta;
    }

    /**
     * @return the Id_pelicula
     */
    public int getId_pelicula() {
        return Id_pelicula;
    }

    /**
     * @param Id_pelicula the Id_pelicula to set
     */
    public void setId_pelicula(int Id_pelicula) {
        this.Id_pelicula = Id_pelicula;
    }

    /**
     * @return the nombrepelicula
     */
    public String getNombrepelicula() {
        return nombrepelicula;
    }

    /**
     * @param nombrepelicula the nombrepelicula to set
     */
    public void setNombrepelicula(String nombrepelicula) {
        this.nombrepelicula = nombrepelicula;
    }

    /**
     * @return the director
     */
    public String getDirector() {
        return director;
    }

    /**
     * @param director the director to set
     */
    public void setDirector(String director) {
        this.director = director;
    }

    /**
     * @return the protagonista
     */
    public String getProtagonista() {
        return protagonista;
    }

    /**
     * @param protagonista the protagonista to set
     */
    public void setProtagonista(String protagonista) {
        this.protagonista = protagonista;
    }

    /**
     * @return the genero
     */
    public String getGenero() {
        return genero;
    }

    /**
     * @param genero the genero to set
     */
    public void setGenero(String genero) {
        this.genero = genero;
    }

    /**
     * @return the precioventa
     */
    public double getPrecioventa() {
        return precioventa;
    }

    /**
     * @param precioventa the precioventa to set
     */
    public void setPrecioventa(double precioventa) {
        this.precioventa = precioventa;
    }

    /**
     * @return the preciorenta
     */
    public double getPreciorenta() {
        return preciorenta;
    }

    /**
     * @param preciorenta the preciorenta to set
     */
    public void setPreciorenta(double preciorenta) {
        this.preciorenta = preciorenta;
    }
    
    
    
}
