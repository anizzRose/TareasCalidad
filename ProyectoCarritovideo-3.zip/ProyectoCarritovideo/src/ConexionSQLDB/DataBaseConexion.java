
package ConexionSQLDB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;


public class DataBaseConexion {  
    
    public static Connection getConnection(){
    try
    {
        Class.forName("com.jdbc.mysql.Driver");
        String miBD="jdbc:mysql://localhost:3307/pablo";
        String usuario="root";
        String contrasena="root";
        Connection conexion= DriverManager.getConnection(miBD, usuario, contrasena);
        return conexion;
    }
    catch(SQLException ex){
        
        System.out.println(ex.getMessage());
    }
    
    catch(ClassNotFoundException ex){
        
        Logger.getLogger(DataBaseConexion.class.getName()).log(Level.SEVERE,null,ex);
    }
        
    
    return null;
  
    }
    
}


