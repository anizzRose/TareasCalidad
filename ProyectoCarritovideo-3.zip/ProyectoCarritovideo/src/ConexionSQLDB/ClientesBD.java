
package ConexionSQLDB;

import Cliente.claseCliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


public class ClientesBD {
  
public ArrayList<claseCliente>ListaClientes(){
 ArrayList<claseCliente>cliente = new ArrayList<claseCliente>();
 try{
  Connection conex=DataBaseConexion.getConnection();
  Statement stat= conex.createStatement();
  ResultSet res= stat.executeQuery("SELECT ID_Cliente,Nombre,Apellidos,Edad,Correo,Usuario,Contraseña"+"FROM CLIENTES ORDER BY 1");
  while(res.next()){
   claseCliente cl = new  claseCliente();  
   cl.setId_cliente(res.getInt("ID_Cliente"));
   cl.setNombre(res.getString("Nombre"));
   cl.setApellidos(res.getString("Apellidos"));
   cl.setEdad(res.getInt("Edad"));
   cl.setCorreo(res.getString("Correo"));
   cl.setUsuario(res.getString("Usuario"));
   cl.setContrasena(res.getString("Contraseña"));
   cliente.add(cl);
  }
 }
 catch(SQLException ex){
     System.out.println(ex.getMessage());
     System.out.println("Error en la lista");   
 }
 return cliente;
}
public void insertarClientes(claseCliente cliente){
    try{
        Connection conex=DataBaseConexion.getConnection();
        PreparedStatement pst=conex.prepareStatement("INSERT INT clientes(ID_CLIENTE,NOMBRE_CLIENTE,APELLIDO_CLIENTE,EDAD,CORREO,USUARIO,CONTRASEÑA)"+"VALUES(?,?,?,?,?,?,?)");
        System.out.println("Los datos se han agregado exitosamente");
        pst.setInt(1,cliente.getId_cliente());
        pst.setString(2,cliente.getNombre());
        pst.setString(3,cliente.getApellidos());
        pst.setInt(4,cliente.getEdad());       
        pst.setString(5,cliente.getCorreo());
        pst.setString(5,cliente.getUsuario());
        pst.setString(7,cliente.getContrasena());
        pst.executeUpdate();
        
        }
    catch(SQLException ex){
        System.out.println(ex.getMessage());
        System.out.println("Error en insertar un Dato");  
    }
    
}
}

